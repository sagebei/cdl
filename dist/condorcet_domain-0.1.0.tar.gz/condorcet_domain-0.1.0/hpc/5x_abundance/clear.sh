rm xc.o* xp.o* xs.o*

git pull