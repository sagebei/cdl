rm rfc.o* rfp.o* rfs.o*

git pull