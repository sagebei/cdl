rm mwc.o* mwp.o* mws.o*

git pull