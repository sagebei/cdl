rm complete.o* sizes.o* parallel.o*

git pull